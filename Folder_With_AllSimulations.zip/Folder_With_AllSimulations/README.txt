In this directory there are two directories with different considerations.
The main one is specified in the directories names.
Note1: All simulations without "noiono" are simulations where there is the applciation of ionos compensation in the creation of the RF simulations 
Note2: The RF simulations can be found in the lab PC in T7(O:)->Microsat Engineering GPS Simulations 